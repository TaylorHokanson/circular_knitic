SparkFun Big Easy Driver Example Code
======================================


Repository Contents
-------------------
* **/Arduija_Demo** - Firmware for the [Arduija Project](https://www.sparkfun.com/news/1631). 
* **/SparkFun_Big_Easy_Driver_Basic_Demo** - Firmware for the [Big Easy Driver Hookup Guide](https://learn.sparkfun.com/tutorials/big-easy-driver-hookup-guide).